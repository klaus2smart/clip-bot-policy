# Clip Bot Policy Pages

This repository contains the Terms of Service and Privacy Policy
required for TikTok Developer App verification.

Files:
- terms.html
- privacy.html

Enable GitHub Pages on the main branch (root).
